﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakeSpecies
{
        public class countryclass //class for country data
        {
            public string Name = ""; //main name
            public string Name_ml = ""; //name in makelang language 
            public string asciiname = ""; //name in plain ascii
            public List<string> altnames = new List<string>(); //alternative names
            public string iso = "XX";
            public string iso3 = "XXX";
            public int isonumber = 0;
            public string fips = "XX";
            public string capital = "";
            public int capital_gnid = 0;
            public double area = 0.0;
            public long population = 0;
            public string continent = "EU";
            public string tld = ".xx";
            public string currencycode = "USD";
            public string currencyname = "Dollar";
            public string phone = "1-999";
            public string postalcode = "#####";
            public string nativewiki = "";
            public List<int> languages = new List<int>();
            public List<string> bordering = new List<string>();
            public double clat = 9999; //lat, long of centroid of country shape
            public double clon = 9999;
        }


}
