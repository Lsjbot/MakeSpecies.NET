﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakeSpecies
{
    public class IUCNClass
    {
        public string Name = "";
        public string status = "";
        public string criteria = "";
        public string year = "";
        public string pop = "";

    }
}
