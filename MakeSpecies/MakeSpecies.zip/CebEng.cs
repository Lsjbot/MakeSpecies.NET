﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using DotNetWikiBot;

namespace MakeSpecies
{
    public partial class CebEng : Form
    {
        Site site;
        public CebEng()
        {
            InitializeComponent();
        }

        public static Site login()
        {
            string makelang = "en";
            //Console.Write("Password: ");
            string password = util.get_password();
            string botkonto = "Lsjbot";
            Site newsite = new Site("https://" + makelang + ".wikipedia.org", botkonto, password);
            newsite.defaultEditComment = "Fixing mistake";
            newsite.minorEditByDefault = true;
            MakeSpecies.loggedin = true;
            return newsite;
        }

        public void memo(string s)
        {
            richTextBox1.AppendText(s + "\n");
            richTextBox1.ScrollToCaret();
        }



        private void Gobutton_Click(object sender, EventArgs e)
        {
            site = login();

            string fn = @"i:\dotnwb3\cebuano species names.txt";

            using (StreamReader sr = new StreamReader(fn))
            {
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    string[] words = line.Split('\t');
                    string cebname = words[1];
                    string latinname = "***";
                    if (words.Length < 4 || String.IsNullOrEmpty(words[3]))
                    {
                        if (words.Length < 3 || String.IsNullOrEmpty(words[2]))
                            continue;
                        Page p = new Page(site, words[2]);
                        util.tryload(p, 1);
                        if (p.Exists())
                        {
                            p.ResolveRedirect();
                            if (p.title != words[2])
                                latinname = p.title;
                            else
                                latinname += "\t" + p.title;
                        }
                    }
                    else
                        latinname = words[3];
                    memo("*"+cebname + "\t" + latinname + "[[:en:"+words[2]+"]]");
                }
            }


        }
    }
}
