﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Threading;
using System.IO;
using DotNetWikiBot;
using System.Text.RegularExpressions;

namespace MakeSpecies
{
    class util
    {
        public static DateTime oldtime = DateTime.Now;
        public static int pausetime = 7; //time between saves, modified depending on task
        public static bool pauseaftersave = true;
        public static Dictionary<string, string> countryaliasdict = new Dictionary<string, string>();
        public static Dictionary<string, string> statedict = new Dictionary<string, string>();
        public static List<countryclass> countrylist = new List<countryclass>();

        public static string[] findtextinbrackets(string input, string start, string end)
        {
          
            Regex r = new Regex(Regex.Escape(start) +"(.*?)"  +Regex.Escape(end));
            MatchCollection matches = r.Matches(input);
            string[] rs = new string[matches.Count];
            int n = 0;
            foreach (Match m in matches)
            {
                rs[n] = m.Groups[1].Value;
                n++;
            }
            return rs;
        }

        public static string fixcase(string ss)
        {
            string s = String.Copy(ss);
            for (int i = 1; i < s.Length; i++)
            {
                if ((s[i - 1] != ' ') && (s[i - 1] != '.'))
                {
                    s = s.Remove(i, 1).Insert(i, Char.ToLower(s[i]).ToString());
                }
            }
            return s;
        }

        public static string unusedfilename(string fn0)
        {
            int n = 1;
            string fn = fn0;
            while (File.Exists(fn))
            {
                fn = fn0.Replace(".", n.ToString() + ".");
                n++;
            }
            return fn;
        }

        public static List<string> getcompasslist()
        {
            List<string> ls = new List<string>();
            ls.Add("North");
            ls.Add("Northwest");
            ls.Add("Northeast");
            ls.Add("North-Central");
            ls.Add("East");
            ls.Add("West");
            ls.Add("South");
            ls.Add("Southwest");
            ls.Add("Southeast");
            ls.Add("South-Central");
            ls.Add("Central");
            ls.Add("West-Central");
            ls.Add("East-Central");
            ls.Add("Eastern");
            ls.Add("Western");
            ls.Add("Southern");
            ls.Add("Northern");
            return ls;

        }

        public static string[] extractcompass(string input)
        {
            string[] output = new string[2] { "", "" };
            string[] words = input.Split();
            foreach (string s in words)
            {
                if (getcompasslist().Contains(s))
                {
                    output[0] = s;
                    output[1] = input.Replace(s, "").Trim();
                    return output;
                }
            }
            Dictionary<string, string> hyphendict = new Dictionary<string, string>()
            {
                {"N-","North" },
                {"NE-","Northeast" },
                {"NW-","Northwest" },
                {"S-","South" },
                {"SE-","Southeast" },
                {"SW-","Southwest" },
                {"NC-","North-Central" },
                {"SC-","South-Central" },
                {"W-","West" },
                {"E-", "East" },
                {"WC-","West-Central" },
                {"EC-", "East-Central" }
            };
            foreach (string hh in hyphendict.Keys)
            {
                if ( input.StartsWith(hh))
                {
                    output[0] = hh;
                    output[1] = input.Replace(hh, "").Trim();
                    return output;
                }
            }
            output[1] = input;
            return output;
        }

        public static string compasscheck(string w)
        {
            string[] ec = util.extractcompass(w);
            if (!String.IsNullOrEmpty(ec[0]))
            {
                return ec[1];
            }
            return w;
        }

        public static string aliascheck(string w)
        {
            if (countryaliasdict.Count == 0)
                countryaliasdict = getcountryalias();
            if (countryaliasdict.ContainsKey(w))
                return countryaliasdict[w];
            else
                return w;
        }

        public static string compassaliascheck(string w, Dictionary<string,int> diststat)
        {
            if (diststat.ContainsKey(w))
                return w;
            w = aliascheck(w);
            if (diststat.ContainsKey(w))
                return w;
            else
                return compasscheck(w);
        }

        public static Dictionary<string,string> getcountryalias()
        {
            Dictionary<string, string> dd = new Dictionary<string, string>();
            dd.Add("Zare", "Democratic Republic of the Congo");
            dd.Add("Zaire", "Democratic Republic of the Congo");
            dd.Add("ZAI", "Democratic Republic of the Congo");
            dd.Add("Congo, Democratic Republic of the", "Democratic Republic of the Congo");
            dd.Add("D.R. Congo", "Democratic Republic of the Congo");
            dd.Add("D.R.Congo", "Democratic Republic of the Congo");
            dd.Add("DR Congo", "Democratic Republic of the Congo");
            //dd.Add("D.R.Congo", "Democratic Republic of the Congo");
            dd.Add("Republic Democratic Congo", "Democratic Republic of the Congo");
            dd.Add("Rpublique Dmocratique du Congo", "Democratic Republic of the Congo");
            dd.Add("Runion", "Réunion");
            dd.Add("Papua New Guinea .", "Papua New Guinea");
            dd.Add("Malaya", "Malaysia");
            dd.Add("Panam", "Panama");
            dd.Add("Masachusettes", "Massachusetts");
            dd.Add("Northwest Territories", "Northwest Territorie");
            dd.Add("USA", "United States of America");
            dd.Add("US", "United States of America");
            dd.Add("USA .", "United States of America");
            dd.Add("United States", "United States of America");
            dd.Add("Etats-Unis", "United States of America");
            dd.Add("Qubec", "Quebec");
            dd.Add("Cte d'Ivoire", "Ivory Coast");
            dd.Add("Cameroun", "Cameroon");
            dd.Add("Russian Far East", "Siberia");
            dd.Add("Russian: FE", "Siberia");
            dd.Add("Russia: FE", "Siberia");
            dd.Add("Russia in Asia", "Siberia");
            dd.Add("Russia (Far East)", "Siberia");
            dd.Add("Congo (Brazzaville)", "Congo-Brazzaville");
            dd.Add("European Russi", "European Russia");
            dd.Add("European Rus", "European Russia");
            dd.Add("European R", "European Russia");
            dd.Add("Europe: Russia", "European Russia");
            dd.Add("Australie", "Australia");
            dd.Add("Tanzanie", "Tanzania");
            dd.Add("Brsil", "Brazil");
            dd.Add("Bolivie", "Bolivia");
            dd.Add("Ile de Borneo", "Borneo");
            dd.Add("Inde", "India");
            dd.Add("Malaisie", "Malaysia");
            dd.Add("Indonsie", "Indonesia");
            dd.Add("Papouasie-Nouvelle-Guine", "Papua New Guinea");
            dd.Add("W-Cape Prov.", "Western Cape Province");
            dd.Add("E-Cape Prov.", "Eastern Cape Province");
            dd.Add("N-Cape Prov.", "Northern Cape Province");
            dd.Add("NSW", "New South Wales");
            dd.Add("Myanmar [Burma]", "Myanmar");
            dd.Add("Burma", "Myanmar");
            dd.Add("Atlantic", "Atlantic Ocean");
            dd.Add("Pacific", "Pacific Ocean");
            dd.Add("Galapagos", "Galapagos Is.");
            dd.Add("BOR-SR", "Borneo");
            dd.Add("BOR", "Borneo");
            dd.Add("BOR-SB", "Borneo");
            dd.Add("BOR-KA", "Borneo");
            dd.Add("BOR-BR", "Borneo");
            dd.Add("PH", "Philippines");
            dd.Add("PHI", "Philippines");
            dd.Add("PHIOO", "Philippines");
            dd.Add("PHI-OO", "Philippines");
            dd.Add("SUM", "Sumatra");
            dd.Add("THA", "Thailand");
            dd.Add("THAOO", "Thailand");
            dd.Add("THA-OO", "Thailand");
            dd.Add("SUL", "Sulawesi");
            dd.Add("MOL", "Moluccas");
            dd.Add("NWG-PN", "Papua New Guinea");
            dd.Add("NWG-IJ", "Irian Jaya");
            dd.Add("NWGPN", "Papua New Guinea");
            dd.Add("NWGIJ", "Irian Jaya");
            dd.Add("LAO", "Laos");
            dd.Add("VIE", "Vietnam");
            dd.Add("VIEOO", "Vietnam");
            dd.Add("VIE-OO", "Vietnam");
            dd.Add("VNM", "Vietnam");
            dd.Add("Cape Prov.", "Cape Provinces");
            dd.Add("Middle America", "Central America");
            dd.Add("Americas  North America", "North America");
            dd.Add("Americas  North America (incl Mexico)", "North America");
            dd.Add("TUR", "Turkey");
            dd.Add("UZB", "Uzbekistan");
            dd.Add("PER", "Peru");
            dd.Add("Chine", "China");
            dd.Add("NWG", "New Guinea");
            dd.Add("Japon", "Japan");
            dd.Add("JP", "Japan");
            dd.Add("JAP", "Japan");
            dd.Add("MDG", "Madagascar");
            dd.Add("MDGOO", "Madagascar");
            dd.Add("MDG-OO", "Madagascar");
            dd.Add("Nouvelle Caldonie", "New Caledonia");
            dd.Add("Nouvelle Zlande", "New Zealand");
            dd.Add("ECU", "Ecuador");
            dd.Add("ECUOO", "Ecuador");
            dd.Add("ECU-OO", "Ecuador");
            dd.Add("Madagascan", "Madagascar");
            dd.Add("Haiti, Dominican Republic", "Hispaniola");
            dd.Add("Australia-Queensland","Queensland");
            dd.Add("Mexique","Mexico");
            dd.Add("RU", "Russia");
            dd.Add("Turkey in Asia", "Turkey");
            dd.Add("Turquie", "Turkey");
            dd.Add("Europe & Asia", "Eurasia");
            dd.Add("Palaearctic", "Eurasia");
            dd.Add("Palearctic", "Eurasia");
            dd.Add("PalaeArctic", "Eurasia");
            dd.Add("peninsular Malaysia", "Malaysia");
            dd.Add("Antarctic Ocean", "Southern Ocean");
            dd.Add("Russian SFSR", "Russia");
            dd.Add("USSR", "Russia");
            dd.Add("Antarctic", "Antarctica");
            dd.Add("Afrotropic", "Afrotropical");
            dd.Add("AfroTropical", "Afrotropical");
            dd.Add("NeoTropical", "South America");
            dd.Add("Neotropical", "South America");
            dd.Add("Neotropical region", "South America");
            dd.Add("Neotropic", "South America");
            dd.Add("BR", "Brazil");
            dd.Add("Indomalaya", "Southeast Asia");
            dd.Add("Rpublique Sud Africaine", "South Africa");
            dd.Add("Eurasia  Asia-Temperate", "Europe & Northern Asia (excluding China)");
            dd.Add("Serbia & Kosovo", "Yugoslavia");
            dd.Add("Bosnia & Hercegovina", "Bosnia and Herzegovina");
            dd.Add("Bosnia and Hercegovina", "Bosnia and Herzegovina");
            dd.Add("Canary Isl.", "Canary Islands");
            dd.Add("Ryukyu Isl.", "Ryukyu Is.");
            dd.Add("Jordania", "Jordan");
            dd.Add("Rpublique Centrafricaine", "Central African Republic");
            dd.Add("Central African Repu", "Central African Republic");
            dd.Add("Oceania  Pacific Islands", "Oceania");
            dd.Add("Britain","Great Britain");
            dd.Add("Nearctic","North America");
            dd.Add("NeArctic", "North America");
            dd.Add("QLDQU", "Queensland");
            dd.Add("QLD", "Queensland");
            dd.Add("Qld", "Queensland");
            dd.Add("Qld.", "Queensland");
            dd.Add("QLD-QU", "Queensland");
            dd.Add("Australia. Queensland", "Queensland");
            dd.Add("Philippines:Luzon","Luzon");
            dd.Add("Asia: Japan", "Japan");
            dd.Add("USA. Hawaii", "Hawaii");
            dd.Add("KEN", "Kenya");
            dd.Add("KEN-OO", "Kenya");
            dd.Add("KENOO", "Kenya");
            dd.Add("FRAFR", "France");
            dd.Add("ITA", "Italy");
            dd.Add("India-Kerala", "Kerala");
            dd.Add("GHA", "Ghana");
            dd.Add("Colombie", "Colombia");
            dd.Add("Australia. New South Wales", "New South Wales");
            dd.Add("Thalande", "Thailand");
            dd.Add("Cape Province", "Cape Provinces");
            dd.Add("India-Uttar Pradesh", "Uttar Pradesh");
            dd.Add("Asia: China", "China");
            dd.Add("Asia: China.", "China");
            dd.Add("USA: California", "California");
            dd.Add("incl Madagascar","Madagascar");
            dd.Add("Windward Islands", "Windward Is.");
            dd.Add("Leeward Islands", "Leeward Is.");
            dd.Add("Bismarck Arch.", "Bismarck Archipelago");
            dd.Add("Jammu & Kashmir", "Jammu-Kashmir");
            dd.Add("Pakistani Kashmir", "Jammu-Kashmir");
            dd.Add("Mediterranean", "Mediterranean Sea");
            dd.Add("Argentine", "Argentina");
            dd.Add("Equateur", "Ecuador");
            dd.Add("Czechia", "Czech Republic");
            dd.Add("Galapagos Isl.", "Galapagos Is.");
            dd.Add("Philippines [Luzon", "Luzon");
            dd.Add("Philippines [Luzon]", "Luzon");
            dd.Add("Celebes", "Sulawesi");
            dd.Add("Galpagos", "Galapagos Is.");
            //dd.Add("China: Yunnan","Yunnan");
            //dd.Add("Oriental(Philippines:Mindanao)","Mindanao");
            //dd.Add("Asia: Mongolia","Mongolia");
            //dd.Add("Peoples' Republic of China","China");
            //dd.Add("Asia: India.","India");
            //dd.Add("Eurasia  Europe","Eurasia");
            //dd.Add("Tropical Indo-Pacific","Indo-Pacific");
            //dd.Add("Indo-West Pacific","Indo-Pacific");
            //dd.Add("Guyane Franaise","French Guiana");
            //dd.Add("Peoples' Republic of China-Fujian","Fujian");
            //dd.Add("Americas  South and Central America","South America");
            //dd.Add("","");
            //dd.Add("","");
            //dd.Add("","");
            //dd.Add("","");
            return dd;
        }

        public static Dictionary<string,string> getstatedict() //US and Canadian state abbreviations
        {
            Dictionary<string, string> localstatedict = new Dictionary<string, string>();
            localstatedict.Add("AL", " Alabama");
            localstatedict.Add("AK", " Alaska");
            localstatedict.Add("AZ", " Arizona");
            localstatedict.Add("AR", " Arkansas");
            localstatedict.Add("CA", " California");
            localstatedict.Add("CO", " Colorado");
            localstatedict.Add("CT", " Connecticut");
            localstatedict.Add("DE", " Delaware");
            localstatedict.Add("DC", " District of Columbia");
            localstatedict.Add("FL", " Florida");
            localstatedict.Add("GA", " Georgia");
            localstatedict.Add("HI", " Hawaii");
            localstatedict.Add("ID", " Idaho");
            localstatedict.Add("IL", " Illinois");
            localstatedict.Add("IN", " Indiana");
            localstatedict.Add("IA", " Iowa");
            localstatedict.Add("KS", " Kansas");
            localstatedict.Add("KY", " Kentucky");
            localstatedict.Add("LA", " Louisiana");
            localstatedict.Add("ME", " Maine");
            localstatedict.Add("MD", " Maryland");
            localstatedict.Add("MA", " Massachusetts");
            localstatedict.Add("MI", " Michigan");
            localstatedict.Add("MN", " Minnesota");
            localstatedict.Add("MS", " Mississippi");
            localstatedict.Add("MO", " Missouri");
            localstatedict.Add("MT", " Montana");
            localstatedict.Add("NE", " Nebraska");
            localstatedict.Add("NV", " Nevada");
            localstatedict.Add("NH", " New Hampshire");
            localstatedict.Add("NJ", " New Jersey");
            localstatedict.Add("NM", " New Mexico");
            localstatedict.Add("NY", " New York");
            localstatedict.Add("NC", " North Carolina");
            localstatedict.Add("ND", " North Dakota");
            localstatedict.Add("OH", " Ohio");
            localstatedict.Add("OK", " Oklahoma");
            localstatedict.Add("OR", " Oregon");
            localstatedict.Add("PA", " Pennsylvania");
            localstatedict.Add("RI", " Rhode Island");
            localstatedict.Add("SC", " South Carolina");
            localstatedict.Add("SD", " South Dakota");
            localstatedict.Add("TN", " Tennessee");
            localstatedict.Add("TX", " Texas");
            localstatedict.Add("UT", " Utah");
            localstatedict.Add("VT", " Vermont");
            localstatedict.Add("VA", " Virginia");
            localstatedict.Add("WA", " Washington");
            localstatedict.Add("WV", " West Virginia");
            localstatedict.Add("WI", " Wisconsin");
            localstatedict.Add("WY", " Wyoming");




            localstatedict.Add("ON", "Ontario");
            localstatedict.Add("QC", "Quebec");
            localstatedict.Add("NS", "Nova Scotia");
            localstatedict.Add("NB", "New Brunswick");

            localstatedict.Add("MB", "Manitoba");
            localstatedict.Add("BC", "British Columbia");
            localstatedict.Add("PE", "Prince Edward Island");
            localstatedict.Add("SK", "Saskatchewan");
            localstatedict.Add("AB", "Alberta");
            localstatedict.Add("NL", "Newfoundland and Labrador");
            localstatedict.Add("YT", "Yukon");
            localstatedict.Add("NT", "Northwest Territories");
            localstatedict.Add("NU", "Nunavut");

            localstatedict.Add("NSW-au", "New South Wales");
            localstatedict.Add("Qld-au", "Queensland");
            localstatedict.Add("Qld.-au", "Queensland");
            localstatedict.Add("SA-au", "South Australia");
            localstatedict.Add("TAS-au", "Tasmania");
            localstatedict.Add("VIC-au", "Victoria");
            localstatedict.Add("QLD-au", "Queensland");
            localstatedict.Add("Tas-au", "Tasmania");
            localstatedict.Add("Tas.-au", "Tasmania");
            localstatedict.Add("Vic-au", "Victoria");
            localstatedict.Add("Vic.-au", "Victoria");
            localstatedict.Add("WA-au", "Western Australia");



            localstatedict.Add("ACT-au", "Australian Capital Territory");
            localstatedict.Add("NT-au", "Northern Territory");

            return localstatedict;
        }

        public static Dictionary<string, int> statestat = new Dictionary<string, int>();

        public static string getstate(string shortstate)
        {
            if (statedict.Count == 0)
                statedict = getstatedict();
            if (shortstate.Length < 10)
                if (!statestat.ContainsKey(shortstate))
                    statestat.Add(shortstate, 0);
            if (statedict.ContainsKey(shortstate))
            {
                statestat[shortstate]++;
                return statedict[shortstate];
            }
            else
            {
                if (shortstate.Length < 10)
                    statestat[shortstate]--;
                return shortstate;
            }
        }

        public static string getcountry(string iso)
        {
            if (countrylist.Count == 0)
                read_country_info();
            var q = from c in countrylist
                    where ((c.iso == iso) || (c.iso3 == iso))
                    select c;
            if (q.Count() == 1)
            {
                return q.First().Name;
            }
            else
                return iso;
            
        }

        public static string geonamesfolder = @"I:\dotnwb3\Geonames\"; 

        public static void read_country_info()
        {
            int n = 0;


            using (StreamReader sr = new StreamReader(geonamesfolder + "countryInfo.txt"))
            {
                int makelangcol = -1;
                while (!sr.EndOfStream)
                {
                    String line = sr.ReadLine();

                    if (line[0] == '#')
                        continue;

                    //if (n > 250)
                    //    Console.WriteLine(line);

                    string[] words = line.Split('\t');

                    //foreach (string s in words)
                    //    Console.WriteLine(s);

                    //Console.WriteLine(words[0] + "|" + words[1]);

                    if (words[0] == "ISO") //headline
                    {
                        //for (int i = 1; i < words.Length; i++)
                        //{
                        //    if (words[i] == makelang)
                        //        makelangcol = i;
                        //}
                        continue;
                    }

                    int geonameid = -1;

                    countryclass country = new countryclass();

                    country.Name = words[4];
                    geonameid = tryconvert(words[16]);
                    country.iso = words[0];
                    country.iso3 = words[1];
                    country.isonumber = tryconvert(words[2]);
                    country.fips = words[3];
                    country.capital = words[5];
                    country.area = tryconvertdouble(words[6]);
                    country.population = tryconvertlong(words[7]);
                    country.continent = words[8];
                    country.tld = words[9];
                    country.currencycode = words[10];
                    country.currencyname = words[11];
                    country.phone = words[12];
                    country.postalcode = words[13];
                    foreach (string ll in words[15].Split(','))
                    {
                        //Console.WriteLine("ll.Split('-')[0] = " + ll.Split('-')[0]);
                        string lcode = ll.Split('-')[0];
                        if (String.IsNullOrEmpty(country.nativewiki))
                            country.nativewiki = lcode;
                        //if (langtoint.ContainsKey(lcode))
                        //    country.languages.Add(langtoint[lcode]);
                    }
                    foreach (string ll in words[17].Split(','))
                        country.bordering.Add(ll);

                    if (makelangcol > 0)
                    {
                        country.Name_ml = words[makelangcol];
                    }
                    else
                    {
                        country.Name_ml = country.Name;
                    }

                    countrylist.Add(country);
                    //countryml.Add(country.Name, country.Name_ml);
                    //countryiso.Add(country.Name, country.iso);

                    //if (geonameid > 0)
                    //{
                    //    countryid.Add(country.iso, geonameid);

                    //    countrydict.Add(geonameid, country);
                    //    //Console.WriteLine(country.iso+":"+geonameid.ToString());
                    //}

                    n++;
                    if ((n % 10) == 0)
                    {
                        Console.WriteLine("n (country_info)   = " + n.ToString());

                    }

                }

                Console.WriteLine("n    (country_info)= " + n.ToString());



            }

            //fill_motherdict();
            //fill_nocapital();
        }

        public static int tryconvert(string word)
        {
            int i = -1;

            if (word.Length == 0)
                return i;

            try
            {
                i = Convert.ToInt32(word);
            }
            catch (OverflowException)
            {
                Console.WriteLine("i Outside the range of the Int32 type: " + word);
            }
            catch (FormatException)
            {
                //if ( !String.IsNullOrEmpty(word))
                //    Console.WriteLine("i Not in a recognizable format: " + word);
            }

            return i;

        }

        public static long tryconvertlong(string word)
        {
            long i = -1;

            if (word.Length == 0)
                return i;

            try
            {
                i = Convert.ToInt64(word);
            }
            catch (OverflowException)
            {
                Console.WriteLine("i Outside the range of the Int64 type: " + word);
            }
            catch (FormatException)
            {
                //Console.WriteLine("i Not in a recognizable long format: " + word);
            }

            return i;

        }

        public static double tryconvertdouble(string word)
        {
            double i = -1;

            if (word.Length == 0)
                return i;

            try
            {
                i = Convert.ToDouble(word);
            }
            catch (OverflowException)
            {
                Console.WriteLine("i Outside the range of the Double type: " + word);
            }
            catch (FormatException)
            {
                try
                {
                    i = Convert.ToDouble(word.Replace(".", ","));
                }
                catch (FormatException)
                {
                    //Console.WriteLine("i Not in a recognizable double format: " + word.Replace(".", ","));
                }
                //Console.WriteLine("i Not in a recognizable double format: " + word);
            }

            return i;

        }


        public static string remove_disambig(string title)
        {
            string tit = title;
            if (tit.IndexOf("(") > 0)
                tit = tit.Remove(tit.IndexOf("(")).Trim();
            else if (tit.IndexOf(",") > 0)
                tit = tit.Remove(tit.IndexOf(",")).Trim();
            //if (tit != title)
            //    Console.WriteLine(title + " |" + tit + "|");
            return tit;
        }

        public static Site login(string makelang)
        {
            string password = util.get_password();
            string botkonto = "Lsjbot";
            Site newsite = new Site("https://" + makelang + ".wikipedia.org", botkonto, password);
            newsite.defaultEditComment = "Fixing mistake";
            newsite.minorEditByDefault = true;
            MakeSpecies.loggedin = true;
            return newsite;
        }



        public static string get_password()
        {
            InputBox ib = new InputBox("Password:",true);
            ib.ShowDialog();
            return ib.gettext();
        }


        public static void make_redirect(string frompage, string topage, string cat)
        {
            make_redirect(frompage, topage, cat, true);
        }

        public static void make_redirect(string frompage, string topage, string cat, bool reallymake)
        {
            Page pred = new Page(MakeSpecies.makesite, frompage);
            if (tryload(pred, 1))
            {
                if (!pred.Exists())
                {
                    pred.text = "#" + MakeSpecies.mp(2, null) + " [[" + topage + "]]";
                    if (!String.IsNullOrEmpty(cat))
                        pred.AddToCategory(cat);
                    trysave(pred, 2,"redirect");
                }

            }

        }

        public static string initialcap(string orig)
        {
            if (String.IsNullOrEmpty(orig))
                return "";

            int initialpos = 0;
            if (orig.IndexOf("[[") == 0)
            {
                if ((orig.IndexOf('|') > 0) && (orig.IndexOf('|') < orig.IndexOf(']')))
                    initialpos = orig.IndexOf('|') + 1;
                else
                    initialpos = 2;
            }
            string s = orig.Substring(initialpos, 1);
            s = s.ToUpper();
            string final = orig;
            final = final.Remove(initialpos, 1).Insert(initialpos, s);
            //s += orig.Remove(0, 1);
            return final;
        }



        public static bool tryload(Page p, int iattempt)
        {
            int itry = 1;


            while (true)
            {

                try
                {
                    p.Load();
                    return true;
                }
                catch (WebException e)
                {
                    string message = e.Message;
                    Console.Error.WriteLine(message);
                    itry++;
                    if (itry > iattempt)
                        return false;
                }
            }

        }

        public static bool trysave(Page p, int iattempt, Site site)
        {
            return trysave(p, iattempt, site.defaultEditComment);
        }

        public static bool trysave(Page p, int iattempt, string editcomment)
        {
            int itry = 1;


            while (true)
            {

                try
                {
                    //Bot.editComment = mp(60);
                    if (!MakeSpecies.savelocally)
                    {
                        p.Save(editcomment, false);
                        DateTime newtime = DateTime.Now;
                        while (newtime < oldtime)
                        {
                            newtime = DateTime.Now;
                            Thread.Sleep(1000);
                        }
                        oldtime = newtime.AddSeconds(pausetime);
                    }
                    else
                    {
                        using (StreamWriter sw = new StreamWriter(MakeSpecies.savefolder + p.title + ".txt"))
                        {
                            sw.WriteLine(p.text);
                        }
                    }


                    if (pauseaftersave)
                    {
                        //Console.WriteLine("<ret>");
                        //Console.ReadKey();
                    }
                    return true;
                }
                catch (WebException e)
                {
                    string message = e.Message;
                    Console.Error.WriteLine("ts we " + message);
                    itry++;
                    if (itry > iattempt)
                        return false;
                    else
                        Thread.Sleep(600000);//milliseconds
                }
                catch (WikiBotException e)
                {
                    string message = e.Message;
                    Console.Error.WriteLine("ts wbe " + message);
                    if (message.Contains("Bad title"))
                        return false;
                    itry++;
                    if (itry > iattempt)
                        return false;
                    else
                        Thread.Sleep(600000);//milliseconds
                }
                catch (IOException e)
                {
                    string message = e.Message;
                    Console.Error.WriteLine("ts ioe " + message);
                    itry++;
                    if (itry > iattempt)
                        return false;
                    else
                        Thread.Sleep(600000);//milliseconds
                }

            }

        }

        public static List<string> findtag(string line)
        {
            string s = line;
            List<string> taglist = new List<string>();
            while (s.IndexOf('<') >= 0)
            {
                if (s.IndexOf('>') < s.IndexOf('<'))
                {
                    Console.WriteLine("Mismatched <> in " + line);
                    s = s.Substring(s.IndexOf('<') + 1);
                }
                else
                {
                    string tag = s.Substring(s.IndexOf('<'), s.IndexOf('>') - s.IndexOf('<') + 1);
                    //Console.WriteLine("Tag = " + tag);
                    taglist.Add(tag);
                    s = s.Substring(s.IndexOf('>') + 1);
                }

            }
            return taglist;
        }

        public static string fixtag(string line)
        {

            string s = line;

            s = s.Replace("<B>", "<b>");
            s = s.Replace("</B>", "</b>");
            s = s.Replace("<I>", "<i>");
            s = s.Replace("</I>", "</i>");

            if (s.Contains("<b>"))
            {
                if (s.Contains("</b>"))
                    s = s.Replace("<b>", "'''").Replace("</b>", "'''");
                else if (s.Contains("</i") && !s.Contains("<i>"))
                    s = s.Replace("<b>", "'''").Replace("</i>", "'''");
            }

            if (s.Contains("<i>"))
            {
                if (s.Contains("</i>"))
                    s = s.Replace("<i>", "''").Replace("</i>", "''");
                else if (s.Contains("</b") && !s.Contains("<b>"))
                    s = s.Replace("<i>", "''").Replace("</b>", "''");
            }

            s = s.Replace("<b>", "");
            s = s.Replace("</b>", "");
            s = s.Replace("<i>", "");
            s = s.Replace("</i>", "");


            return s;
        }

        public static bool is_latin(string name)
        {
            return (get_alphabet(name) == "latin");
        }

        public static string get_alphabet(string name)
        {
            char[] letters = name.ToCharArray();
            //char[] letters = remove_disambig(name).ToCharArray();
            int n = 0;
            int sum = 0;
            //int nlatin = 0;
            Dictionary<string, int> alphdir = new Dictionary<string, int>();
            foreach (char c in letters)
            {
                int uc = Convert.ToInt32(c);
                sum += uc;
                string alphabet = "none";
                if (uc <= 0x0040) alphabet = "none";
                //else if ((uc >= 0x0030) && (uc <= 0x0039)) alphabet = "number";
                //else if ((uc >= 0x0020) && (uc <= 0x0040)) alphabet = "punctuation";
                else if ((uc >= 0x0041) && (uc <= 0x007F)) alphabet = "latin";
                else if ((uc >= 0x00A0) && (uc <= 0x00FF)) alphabet = "latin";
                else if ((uc >= 0x0100) && (uc <= 0x017F)) alphabet = "latin";
                else if ((uc >= 0x0180) && (uc <= 0x024F)) alphabet = "latin";
                else if ((uc >= 0x0250) && (uc <= 0x02AF)) alphabet = "phonetic";
                else if ((uc >= 0x02B0) && (uc <= 0x02FF)) alphabet = "spacing modifier letters";
                else if ((uc >= 0x0300) && (uc <= 0x036F)) alphabet = "combining diacritical marks";
                else if ((uc >= 0x0370) && (uc <= 0x03FF)) alphabet = "greek and coptic";
                else if ((uc >= 0x0400) && (uc <= 0x04FF)) alphabet = "cyrillic";
                else if ((uc >= 0x0500) && (uc <= 0x052F)) alphabet = "cyrillic";
                else if ((uc >= 0x0530) && (uc <= 0x058F)) alphabet = "armenian";
                else if ((uc >= 0x0590) && (uc <= 0x05FF)) alphabet = "hebrew";
                else if ((uc >= 0x0600) && (uc <= 0x06FF)) alphabet = "arabic";
                else if ((uc >= 0x0700) && (uc <= 0x074F)) alphabet = "syriac";
                else if ((uc >= 0x0780) && (uc <= 0x07BF)) alphabet = "thaana";
                else if ((uc >= 0x0900) && (uc <= 0x097F)) alphabet = "devanagari";
                else if ((uc >= 0x0980) && (uc <= 0x09FF)) alphabet = "bengali";
                else if ((uc >= 0x0A00) && (uc <= 0x0A7F)) alphabet = "gurmukhi";
                else if ((uc >= 0x0A80) && (uc <= 0x0AFF)) alphabet = "gujarati";
                else if ((uc >= 0x0B00) && (uc <= 0x0B7F)) alphabet = "oriya";
                else if ((uc >= 0x0B80) && (uc <= 0x0BFF)) alphabet = "tamil";
                else if ((uc >= 0x0C00) && (uc <= 0x0C7F)) alphabet = "telugu";
                else if ((uc >= 0x0C80) && (uc <= 0x0CFF)) alphabet = "kannada";
                else if ((uc >= 0x0D00) && (uc <= 0x0D7F)) alphabet = "malayalam";
                else if ((uc >= 0x0D80) && (uc <= 0x0DFF)) alphabet = "sinhala";
                else if ((uc >= 0x0E00) && (uc <= 0x0E7F)) alphabet = "thai";
                else if ((uc >= 0x0E80) && (uc <= 0x0EFF)) alphabet = "lao";
                else if ((uc >= 0x0F00) && (uc <= 0x0FFF)) alphabet = "tibetan";
                else if ((uc >= 0x1000) && (uc <= 0x109F)) alphabet = "myanmar";
                else if ((uc >= 0x10A0) && (uc <= 0x10FF)) alphabet = "georgian";
                else if ((uc >= 0x1100) && (uc <= 0x11FF)) alphabet = "korean";
                else if ((uc >= 0x1200) && (uc <= 0x137F)) alphabet = "ethiopic";
                else if ((uc >= 0x13A0) && (uc <= 0x13FF)) alphabet = "cherokee";
                else if ((uc >= 0x1400) && (uc <= 0x167F)) alphabet = "unified canadian aboriginal syllabics";
                else if ((uc >= 0x1680) && (uc <= 0x169F)) alphabet = "ogham";
                else if ((uc >= 0x16A0) && (uc <= 0x16FF)) alphabet = "runic";
                else if ((uc >= 0x1700) && (uc <= 0x171F)) alphabet = "tagalog";
                else if ((uc >= 0x1720) && (uc <= 0x173F)) alphabet = "hanunoo";
                else if ((uc >= 0x1740) && (uc <= 0x175F)) alphabet = "buhid";
                else if ((uc >= 0x1760) && (uc <= 0x177F)) alphabet = "tagbanwa";
                else if ((uc >= 0x1780) && (uc <= 0x17FF)) alphabet = "khmer";
                else if ((uc >= 0x1800) && (uc <= 0x18AF)) alphabet = "mongolian";
                else if ((uc >= 0x1900) && (uc <= 0x194F)) alphabet = "limbu";
                else if ((uc >= 0x1950) && (uc <= 0x197F)) alphabet = "tai le";
                else if ((uc >= 0x19E0) && (uc <= 0x19FF)) alphabet = "khmer";
                else if ((uc >= 0x1D00) && (uc <= 0x1D7F)) alphabet = "phonetic";
                else if ((uc >= 0x1E00) && (uc <= 0x1EFF)) alphabet = "latin";
                else if ((uc >= 0x1F00) && (uc <= 0x1FFF)) alphabet = "greek and coptic";
                else if ((uc >= 0x2000) && (uc <= 0x206F)) alphabet = "none";
                else if ((uc >= 0x2070) && (uc <= 0x209F)) alphabet = "none";
                else if ((uc >= 0x20A0) && (uc <= 0x20CF)) alphabet = "none";
                else if ((uc >= 0x20D0) && (uc <= 0x20FF)) alphabet = "combining diacritical marks for symbols";
                else if ((uc >= 0x2100) && (uc <= 0x214F)) alphabet = "letterlike symbols";
                else if ((uc >= 0x2150) && (uc <= 0x218F)) alphabet = "none";
                else if ((uc >= 0x2190) && (uc <= 0x21FF)) alphabet = "none";
                else if ((uc >= 0x2200) && (uc <= 0x22FF)) alphabet = "none";
                else if ((uc >= 0x2300) && (uc <= 0x23FF)) alphabet = "none";
                else if ((uc >= 0x2400) && (uc <= 0x243F)) alphabet = "none";
                else if ((uc >= 0x2440) && (uc <= 0x245F)) alphabet = "optical character recognition";
                else if ((uc >= 0x2460) && (uc <= 0x24FF)) alphabet = "enclosed alphanumerics";
                else if ((uc >= 0x2500) && (uc <= 0x257F)) alphabet = "none";
                else if ((uc >= 0x2580) && (uc <= 0x259F)) alphabet = "none";
                else if ((uc >= 0x25A0) && (uc <= 0x25FF)) alphabet = "none";
                else if ((uc >= 0x2600) && (uc <= 0x26FF)) alphabet = "none";
                else if ((uc >= 0x2700) && (uc <= 0x27BF)) alphabet = "none";
                else if ((uc >= 0x27C0) && (uc <= 0x27EF)) alphabet = "none";
                else if ((uc >= 0x27F0) && (uc <= 0x27FF)) alphabet = "none";
                else if ((uc >= 0x2800) && (uc <= 0x28FF)) alphabet = "braille";
                else if ((uc >= 0x2900) && (uc <= 0x297F)) alphabet = "none";
                else if ((uc >= 0x2980) && (uc <= 0x29FF)) alphabet = "none";
                else if ((uc >= 0x2A00) && (uc <= 0x2AFF)) alphabet = "none";
                else if ((uc >= 0x2B00) && (uc <= 0x2BFF)) alphabet = "none";
                else if ((uc >= 0x2E80) && (uc <= 0x2EFF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x2F00) && (uc <= 0x2FDF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x2FF0) && (uc <= 0x2FFF)) alphabet = "none";
                else if ((uc >= 0x3000) && (uc <= 0x303F)) alphabet = "chinese/japanese";
                else if ((uc >= 0x3040) && (uc <= 0x309F)) alphabet = "chinese/japanese";
                else if ((uc >= 0x30A0) && (uc <= 0x30FF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x3100) && (uc <= 0x312F)) alphabet = "bopomofo";
                else if ((uc >= 0x3130) && (uc <= 0x318F)) alphabet = "korean";
                else if ((uc >= 0x3190) && (uc <= 0x319F)) alphabet = "chinese/japanese";
                else if ((uc >= 0x31A0) && (uc <= 0x31BF)) alphabet = "bopomofo";
                else if ((uc >= 0x31F0) && (uc <= 0x31FF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x3200) && (uc <= 0x32FF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x3300) && (uc <= 0x33FF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x3400) && (uc <= 0x4DBF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x4DC0) && (uc <= 0x4DFF)) alphabet = "none";
                else if ((uc >= 0x4E00) && (uc <= 0x9FFF)) alphabet = "chinese/japanese";
                else if ((uc >= 0xA000) && (uc <= 0xA48F)) alphabet = "chinese/japanese";
                else if ((uc >= 0xA490) && (uc <= 0xA4CF)) alphabet = "chinese/japanese";
                else if ((uc >= 0xAC00) && (uc <= 0xD7AF)) alphabet = "korean";
                else if ((uc >= 0xD800) && (uc <= 0xDB7F)) alphabet = "high surrogates";
                else if ((uc >= 0xDB80) && (uc <= 0xDBFF)) alphabet = "high private use surrogates";
                else if ((uc >= 0xDC00) && (uc <= 0xDFFF)) alphabet = "low surrogates";
                else if ((uc >= 0xE000) && (uc <= 0xF8FF)) alphabet = "private use area";
                else if ((uc >= 0xF900) && (uc <= 0xFAFF)) alphabet = "chinese/japanese";
                else if ((uc >= 0xFB00) && (uc <= 0xFB4F)) alphabet = "alphabetic presentation forms";
                else if ((uc >= 0xFB50) && (uc <= 0xFDFF)) alphabet = "arabic";
                else if ((uc >= 0xFE00) && (uc <= 0xFE0F)) alphabet = "variation selectors";
                else if ((uc >= 0xFE20) && (uc <= 0xFE2F)) alphabet = "combining half marks";
                else if ((uc >= 0xFE30) && (uc <= 0xFE4F)) alphabet = "chinese/japanese";
                else if ((uc >= 0xFE50) && (uc <= 0xFE6F)) alphabet = "small form variants";
                else if ((uc >= 0xFE70) && (uc <= 0xFEFF)) alphabet = "arabic";
                else if ((uc >= 0xFF00) && (uc <= 0xFFEF)) alphabet = "halfwidth and fullwidth forms";
                else if ((uc >= 0xFFF0) && (uc <= 0xFFFF)) alphabet = "specials";
                else if ((uc >= 0x10000) && (uc <= 0x1007F)) alphabet = "linear b";
                else if ((uc >= 0x10080) && (uc <= 0x100FF)) alphabet = "linear b";
                else if ((uc >= 0x10100) && (uc <= 0x1013F)) alphabet = "aegean numbers";
                else if ((uc >= 0x10300) && (uc <= 0x1032F)) alphabet = "old italic";
                else if ((uc >= 0x10330) && (uc <= 0x1034F)) alphabet = "gothic";
                else if ((uc >= 0x10380) && (uc <= 0x1039F)) alphabet = "ugaritic";
                else if ((uc >= 0x10400) && (uc <= 0x1044F)) alphabet = "deseret";
                else if ((uc >= 0x10450) && (uc <= 0x1047F)) alphabet = "shavian";
                else if ((uc >= 0x10480) && (uc <= 0x104AF)) alphabet = "osmanya";
                else if ((uc >= 0x10800) && (uc <= 0x1083F)) alphabet = "cypriot syllabary";
                else if ((uc >= 0x1D000) && (uc <= 0x1D0FF)) alphabet = "byzantine musical symbols";
                else if ((uc >= 0x1D100) && (uc <= 0x1D1FF)) alphabet = "musical symbols";
                else if ((uc >= 0x1D300) && (uc <= 0x1D35F)) alphabet = "tai xuan jing symbols";
                else if ((uc >= 0x1D400) && (uc <= 0x1D7FF)) alphabet = "none";
                else if ((uc >= 0x20000) && (uc <= 0x2A6DF)) alphabet = "chinese/japanese";
                else if ((uc >= 0x2F800) && (uc <= 0x2FA1F)) alphabet = "chinese/japanese";
                else if ((uc >= 0xE0000) && (uc <= 0xE007F)) alphabet = "none";

                bool ucprint = false;
                if (alphabet != "none")
                {
                    n++;
                    if (!alphdir.ContainsKey(alphabet))
                        alphdir.Add(alphabet, 0);
                    alphdir[alphabet]++;
                }
                else if (uc != 0x0020)
                {
                    //Console.Write("c=" + c.ToString() + ", uc=0x" + uc.ToString("x5") + "|");
                    //ucprint = true;
                }
                if (ucprint)
                    Console.WriteLine();
            }

            int nmax = 0;
            string alphmax = "none";
            foreach (string alph in alphdir.Keys)
            {
                //Console.WriteLine("ga:" + alph + " " + alphdir[alph].ToString());
                if (alphdir[alph] > nmax)
                {
                    nmax = alphdir[alph];
                    alphmax = alph;
                }
            }

            if (letters.Length > 2 * n) //mostly non-alphabetic
                return "none";
            else if (nmax > n / 2) //mostly same alphabet
                return alphmax;
            else
                return "mixed"; //mixed alphabets
        }


    }


}
