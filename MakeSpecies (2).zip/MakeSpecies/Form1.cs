﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using DotNetWikiBot;

namespace MakeSpecies
{


    public partial class Form1 : Form
    {



        COL2019 db;
        static string connectionstring = "Data Source=DESKTOP-JOB29A9;Initial Catalog=\"COL2019\";Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            db = new COL2019(connectionstring);

        }

        public static statclass stats = new statclass();


        //==============================================================================


        private void Quitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CompareTreebutton_Click(object sender, EventArgs e)
        {
            MScomparetrees mct = new MScomparetrees(db);
            mct.Show();
        }

        public void memo(string s)
        {
            richTextBox1.AppendText(s + "\n");
            richTextBox1.ScrollToCaret();
        }


        private void langfixbutton_Click(object sender, EventArgs e)
        {
            Dictionary<string, string> langdict = new Dictionary<string, string>();
            langdict.Add("Visayan", "Cebuano");
            langdict.Add("En", "English");
            langdict.Add("Eng", "English");
            langdict.Add("Jpn", "Japanese");
            langdict.Add("Jpn (Kanji)", "Japanese");
            langdict.Add("Jpn (Katakana)", "Japanese");
            langdict.Add("Spainsh", "Spanish");
            langdict.Add("Swe", "Swedish");

            foreach (string oldlang in langdict.Keys)
            {

                //                UPDATE Customers
                //SET ContactName = 'Alfred Schmidt', City = 'Frankfurt'
                //WHERE CustomerID = 1;

                //string insertStatement = "Insert into Employee values('Experts', 'Comment','alpha.beta@gmail.com')";
                string update = "UPDATE VernacularName SET Language = '" + langdict[oldlang] + "' where Language='" + oldlang + "';";

                memo(oldlang + ": " + update);

                db.ExecuteQuery<VernacularName>(update);

                //(from c in db.VernacularName where c.Language == oldlang select c).ToList().ForEach(x => x.Language = langdict[oldlang]);
                //memo(oldlang + ": " + q.Count());
                //int i = 0;
                //foreach (VernacularName c in q)
                //{
                //    memo(c.Language);
                //    c.Language = langdict[oldlang];
                //    memo(c.Language);
                //    i++;
                //    if (i > 10)
                //        break;
                //}
                //var q1 = (from c in q where c.Language == oldlang select c).ToList();
                //memo(oldlang + " (after): " + q.Count());
                //VernacularName dum = new VernacularName();
                //dum.TaxonID = 9692186;
                //dum.Language = "AAAAAAA";
                //dum.VernacularName1 = "AAAAA";
                //db.VernacularName.InsertOnSubmit(dum);
                //db.SubmitChanges();
            }
            memo("Done");

        }

        private void duplicatebutton_Click(object sender, EventArgs e)
        {
            int n = 0;
            Dictionary<string, int> namedict = new Dictionary<string, int>();
            Dictionary<string, List<int>> doubledict = new Dictionary<string, List<int>>();

            int nmax = 100000000;

            foreach (Taxon tt in db.Taxon)
            {
                if (tt.TaxonomicStatus != null && tt.TaxonomicStatus != "accepted name")
                    continue;
                string name = MakeSpecies.dbtaxon_name(tt);
                if ( namedict.ContainsKey(name))
                {
                    memo("Double found " + name);
                    if (!doubledict.ContainsKey(name))
                    {
                        doubledict.Add(name, new List<int>());
                        doubledict[name].Add(namedict[name]);
                    }
                    doubledict[name].Add(tt.TaxonID);
                }
                else
                {
                    namedict.Add(name, tt.TaxonID);
                }
                n++;
                if (n % 100 == 0)
                    memo("n = " + n);
                if (n > nmax)
                    break;
            }

            foreach (string s in doubledict.Keys)
            {
                StringBuilder sb = new StringBuilder(s);
                foreach (int i in doubledict[s])
                    sb.Append(", " + i);
                memo(sb.ToString());
            }
            memo("Duplicates done!");
        }

        private void makebutton_Click(object sender, EventArgs e)
        {
            MakeSpecies ms = new MakeSpecies(db);
            ms.Show();
        }

        private void cebengbutton_Click(object sender, EventArgs e)
        {
            CebEng ce = new CebEng();
            ce.Show();
        }


        private void Badfindbutton_Click(object sender, EventArgs e)
        {
            //InputBox ib = new InputBox("Category to check for bad articles:", false);
            //ib.ShowDialog();
            //string cat = ib.gettext();

            BadArticles ba = new BadArticles(db);
            ba.Show();

        }

        private void Distributionbutton_Click(object sender, EventArgs e)
        {
            DistributiontestForm df = new DistributiontestForm(db);
            df.Show();
        }
    }
}
