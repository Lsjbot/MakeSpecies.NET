﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MakeSpecies
{
    public class Taxonclass
    {
        public int taxonid; //index to various other list; COL id#; if no COLid, then dyntaxaid + 20 million
        public int taxonid13 = -1;
        public int dyntaxaid = -1; //taxon id in Dyntaxa; -1 if none
        public int dyntaxa2 = -1; //index to taxondict entry for second (3rd etc) Dyntaxa taxon
        public int iucnid = -1;
        public int redfiid = -1;
        public int redsvid = -1;
        public string Name = ""; //scientific name
        public string Name_sv = ""; //Swedish name
        public int Level = -1; //taxonomic level, index to rank_name
        public int Parent = -1; //index of parent in COL; -1 if top taxon; -2 if taxon only in dyntaxa; -3 if taxon is double dyntaxa entry.
        public int dyntaxa_Parent = -1; //index of parent in dyntaxa
        public int Parent11 = -1;
        public int Parent13 = -1;
        public string Parentname = "";
        public List<int> Children = new List<int>(); //index of children
        public List<int> Children13 = new List<int>(); //index of children
        public List<int> dyntaxa_Children = new List<int>(); //index of children
        public string dyntaxa_auktor = "";
        public string dyntaxa_name = "";
        public string iucn_auktor = "";
        public string iucn_name = "";
        public string redfi_name = "";
        public string redsv_name = "";
        public List<int> habitats = new List<int>();
        public List<int> synonyms = new List<int>();
        public string regnum;
        public string articlename = "";

        public string auktor;
        public string source_dataset;

    }
}
